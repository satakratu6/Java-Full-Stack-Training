package com.capg.patient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentPatientApplicationTests {

	@Test
	void contextLoads() {
	}

}
